Warning: This tarball is for SDL2 library and is only tested with Ubuntu. You might have to tweak the Makefile for Mac.

Usage:
1. Run the simulation program with "-o <filename>" option.
2. Run "visualize <filename>" with the file produced.
